// LED Light for CAPSLOCK
void led_set_user(uint8_t usb_led) {
	if (usb_led & (1 << USB_LED_CAPS_LOCK)) {
		DDRF |= (1 << 4); PORTF &= ~(1 << 4);   // Port F4
	} else {
		DDRF &= ~(1 << 4); PORTF &= ~(1 << 4);
	}
}

// ============================================================================
// Config Light MATRIX
led_config_t g_led_config = {
	{
	{NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED},
	{NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED},
	{NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED, NO_LED},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
	},
	{
	// LED Index to Physical Position ??
	{0,0},{0,1},{0,2},{0,3},{0,4},{0,5},{0,6},{0,7},{0,8},{0,9},{0,10},{0,11},{0,12},{0,13},{0,14},{0,15}
	}, 
	{
	// LED Index to Flag ??
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
	}
};

// Light LEDs when keyboard layer is active
void rgb_matrix_indicators_user(void) {
   if (IS_LAYER_ON(0)) { 
     rgb_matrix_set_color_all(RGB_BLACK); // LED Index, R, G, B or Index, RGB_COLOR
     rgb_matrix_set_color(3, RGB_CYAN);
     rgb_matrix_set_color(6, RGB_GREEN);
     rgb_matrix_set_color(7, RGB_BLUE);
     rgb_matrix_set_color(8, RGB_SPRINGGREEN);
     rgb_matrix_set_color(10, RGB_PURPLE);
   }
   if (IS_LAYER_ON(1)) { 
     rgb_matrix_set_color_all(RGB_CYAN);
     rgb_matrix_set_color(3, RGB_RED);
   }
   if (IS_LAYER_ON(2)) { 
     rgb_matrix_set_color_all(RGB_GREEN);
     rgb_matrix_set_color(6, RGB_RED);
   }
   if (IS_LAYER_ON(3)) { 
     rgb_matrix_set_color_all(RGB_BLUE);
     rgb_matrix_set_color(7, RGB_RED);
   }
   if (IS_LAYER_ON(4)) { 
     rgb_matrix_set_color_all(RGB_SPRINGGREEN);
     rgb_matrix_set_color(8, RGB_RED);
   }
   if (IS_LAYER_ON(5)) { 
     rgb_matrix_set_color_all(RGB_PURPLE);
     rgb_matrix_set_color(10, RGB_RED);
   }
}
// ============================================================================
