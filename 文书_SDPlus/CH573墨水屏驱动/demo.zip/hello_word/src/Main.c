/********************************** (C) COPYRIGHT *******************************
 * File Name          : Main.c
 * Author             : ��������������ʵ����
 * Version            : V1.0
 * Date               : 2022/2/22
 * Description          : 2.66����ɫīˮ������demo
 *******************************************************************************/

#include "CH57x_common.h"

//��Ļ����
#define ALLSCREEN_GRAGHBYTES 5624

//GPIOB
#define BUSY_Pin GPIO_Pin_11
#define RES_Pin GPIO_Pin_10
#define DC_Pin GPIO_Pin_7
//GPIOA
#define CS_Pin GPIO_Pin_12
#define SCK_Pin GPIO_Pin_13
#define MOSI_Pin GPIO_Pin_14

#define EPD_3C266_DC_0 GPIOB_ResetBits(DC_Pin)
#define EPD_3C266_DC_1 GPIOB_SetBits(DC_Pin)
#define EPD_3C266_RST_0 GPIOB_ResetBits(RES_Pin)
#define EPD_3C266_RST_1 GPIOB_SetBits(RES_Pin)
#define isEPD_W21_BUSY GPIOB_ReadPortPin(BUSY_Pin)


///////Ӳ����ʼ��/////////
void DebugInit( void );
void SPI0_INIT(void);
void EPD_IO_INIT(void);

///////īˮ�����////////

/**
 * @brief �����Ļ�Ƿ���BUSY
 *
 */
void Epaper_READBUSY(void);

/**
 * @brief ����Ļд��һ���ֽ�����
 *
 * @param cmd Ҫд�������ֵ
 */
void Epaper_Write_Command(unsigned char cmd);

/**
 * @brief ����Ļд��һ���ֽ�����
 *
 * @param datas Ҫд�����ݵ�ֵ
 */
void Epaper_Write_Data(unsigned char datas);

/**
 * @brief īˮ����ȫˢ��ʼ������֧�ֺڰף�
 *
 */
void EPD_HW_Init(void);   //Electronic paper initialization

/**
 * @brief īˮ���ľ�ˢ��ʼ�����ھ�ˢǰ����
 *
 */
void EPD_Part_Init(void); //Local refresh initialization

/**
 * @brief īˮ���ľ�ˢ����
 *
 */
void EPD_Part_Update(void);

/**
 * @brief īˮ����ȫˢ����
 *
 */
void EPD_Update(void);

/**
 * @brief ��Ļˢȫ��
 *
 */
void EPD_WhiteScreen_Black(void);

/**
 * @brief ��Ļˢȫ��
 *
 */
void EPD_WhiteScreen_White(void);

/**
 * @brief īˮ���������˯��ģʽ������ˢ����ͽ������ģʽ
 *
 */
void EPD_DeepSleep(void);
//Display

/**
 * @brief ȫˢĳͼƬ����֧�ֺڰף�
 *
 * @param datas ͼƬ���飬ʹ��Image2Lcdȡģ����ֱɨ�衢��Ҫͼ��ͷ����ѡ��ɫ��ת���ֱ���Ϊ296*152
 */
void EPD_WhiteScreen_ALL(const unsigned char *datas);

/**
 * @brief ���þ�ˢ����
 *
 * @param datas ͼƬ���飬ʹ��Image2Lcdȡģ����ֱɨ�衢��Ҫͼ��ͷ����ѡ��ɫ��ת���ֱ���Ϊ296*152
 */
void EPD_SetRAMValue_BaseMap(const unsigned char *datas);

/**
 * @brief ��ˢĳͼƬ
 *
 * @param x_start ͼƬ��ʼx��ַ
 * @param y_start ͼƬ��ʼy��ַ
 * @param datas ͼƬ���飬ʹ��Image2Lcdȡģ��
 * @param PART_COLUMN ͼƬ�߶�
 * @param PART_LINE ͼƬ����
 */
void EPD_Dis_Part(unsigned int x_start, unsigned int y_start, const unsigned char *datas, unsigned int PART_COLUMN, unsigned int PART_LINE);

const unsigned char LUT_DATA[]= {
0x08,0x66,0x48,0x40,0x00,0x00,0x00,
0x20,0x66,0x12,0x20,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,

0x05,0x00,0x00,0x05,0x00,
0x06,0x06,0x06,0x06,0x02,
0x00,0x00,0x15,0x20,0x00,
0x25,0x00,0x00,0x00,0x00,
0x05,0x00,0x00,0x00,0x01,
0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,

0x15,0x41,0xA8,0x32,0x30,0x0A,
};

const unsigned char LUT_DATA_part[]={
0X00,0x40,0x00,0x00,0x00,0x00,0x00,
0X80,0x80,0x00,0x00,0x00,0x00,0x00,
0X40,0x40,0x00,0x00,0x00,0x00,0x00,
0X00,0x80,0x00,0x00,0x00,0x00,0x00,
0X00,0x00,0x00,0x00,0x00,0x00,0x00,

0x14,0x00,0x00,0x00,0x02,
0x04,0x00,0x00,0x00,0x01,
0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,

0x15,0x41,0xA8,0x32,0x30,0x0A,
};

void SPI0_MasterInit( void )
{
    R8_SPI0_CLOCK_DIV = 4;      // ��Ƶʱ��4��Ƶ
    R8_SPI0_CTRL_MOD = RB_SPI_ALL_CLEAR;
    R8_SPI0_CTRL_MOD = RB_SPI_MOSI_OE | RB_SPI_SCK_OE ;
    R8_SPI0_CTRL_CFG |= RB_SPI_AUTO_IF;        // ����BUFFER/FIFO�Զ����IF_BYTE_END��־
    R8_SPI0_CTRL_CFG &= ~RB_SPI_DMA_ENABLE;    // ������DMA��ʽ
}

int pgm_read_byte(unsigned char data)
{
    const uint8_t pmg_data = data;
    return pmg_data;
}
void DebugInit( void )
{
  GPIOA_SetBits( GPIO_Pin_9 );
  GPIOA_ModeCfg( GPIO_Pin_8, GPIO_ModeIN_PU );
  GPIOA_ModeCfg( GPIO_Pin_9, GPIO_ModeOut_PP_5mA );
  UART1_DefInit();
}

void SPI0_INIT(void){
    //PRINT( "1.spi0 mul master mode send data ...\n" );
    //DelayMs( 100 );
    GPIOA_SetBits( CS_Pin );
    GPIOA_ModeCfg( CS_Pin | SCK_Pin | MOSI_Pin, GPIO_ModeOut_PP_5mA );
    //SPI0_MasterDefInit();
    SPI0_MasterInit();
    //PRINT("SPI0 INIT COMPLETE!");
}

void EPD_IO_INIT(){
    //PRINT("EPD IO INIT START!");
    GPIOB_ModeCfg(DC_Pin | RES_Pin, GPIO_ModeOut_PP_5mA);
    GPIOB_ModeCfg(BUSY_Pin, GPIO_ModeIN_Floating);
    //PRINT("EPD IO INIT COMPLETE!");
}

///////// īˮ��SPI������غ��� //////////////////
void Epaper_Write_Command(unsigned char cmd)
{
  EPD_3C266_DC_0; // command write
  GPIOA_ResetBits( CS_Pin );
  SPI0_MasterSendByte( cmd );
  GPIOA_SetBits( CS_Pin );
  //DelayUs(1);
  //GPIOA_ResetBits( GPIO_Pin_12 );
  //i = SPI0_MasterRecvByte();
  //GPIOA_SetBits( GPIO_Pin_12 );
  //DelayMs( 2 );
  EPD_3C266_DC_1;
}
void Epaper_Write_Data(unsigned char datas)
{
  EPD_3C266_DC_1; // data write
  GPIOA_ResetBits( CS_Pin );
  SPI0_MasterSendByte( datas );
  GPIOA_SetBits(CS_Pin);
  //DelayUs(2);
}

///////// īˮ�����ܲ������� /////////
//SSD1675
void EPD_HW_Init(void)
{
  EPD_3C266_RST_0; // Module reset
  DelayMs(1);     //At least 10ms delay
  EPD_3C266_RST_1;
  DelayMs(1); //At least 10ms delay

  Epaper_READBUSY();
  Epaper_Write_Command(0x12); // soft reset
  Epaper_READBUSY();

  Epaper_Write_Command(0x74); //set analog block control
  Epaper_Write_Data(0x54);
  Epaper_Write_Command(0x7E); //set digital block control
  Epaper_Write_Data(0x3B);

  Epaper_Write_Command(0x01); //Driver output control
  Epaper_Write_Data(0x27);
  Epaper_Write_Data(0x01);
  Epaper_Write_Data(0x00);

  Epaper_Write_Command(0x11); //data entry mode
  Epaper_Write_Data(0x01);

  Epaper_Write_Command(0x44); //set Ram-X address start/end position
  Epaper_Write_Data(0x00);
  Epaper_Write_Data(0x12); //0x0C-->(15+1)*8=128

  Epaper_Write_Command(0x45); //set Ram-Y address start/end position
  Epaper_Write_Data(0x27);    //0xF9-->(249+1)=250
  Epaper_Write_Data(0x01);
  Epaper_Write_Data(0x00);
  Epaper_Write_Data(0x00);

  Epaper_Write_Command(0x3C); //BorderWavefrom
  Epaper_Write_Data(0x03);

  Epaper_Write_Command(0x2C); //VCOM Voltage
  Epaper_Write_Data(0x70);    //

  Epaper_Write_Command(0x03); // Gate Driving Voltage Control
  Epaper_Write_Data(LUT_DATA[70]);

  Epaper_Write_Command(0x04); // Source Driving Voltage Control
  Epaper_Write_Data(LUT_DATA[71]);
  Epaper_Write_Data(LUT_DATA[72]);
  Epaper_Write_Data(LUT_DATA[73]);

  Epaper_Write_Command(0x3A); //Dummy Line
  Epaper_Write_Data(LUT_DATA[74]);
  Epaper_Write_Command(0x3B); //Gate time
  Epaper_Write_Data(LUT_DATA[75]);

  EPD_select_LUT((unsigned char *)LUT_DATA); //LUT

  Epaper_Write_Command(0x4E); // set RAM x address count to 0;
  Epaper_Write_Data(0x00);
  Epaper_Write_Command(0x4F); // set RAM y address count to 0X127;
  Epaper_Write_Data(0x27);
  Epaper_Write_Data(0x01);
  Epaper_READBUSY();
}

void EPD_WhiteScreen_ALL(const unsigned char *datas)
{
  unsigned int i;
  Epaper_Write_Command(0x24); //write RAM for black(0)/white (1)
  for (i = 0; i < ALLSCREEN_GRAGHBYTES; i++)
  { //�˴�ӦΪpgm_read_byte(&datas[i]) ��ʱ������ֲ
    Epaper_Write_Data(&datas[i]);
  }
  Epaper_Write_Command(0x26);
  for (i = 0; i < ALLSCREEN_GRAGHBYTES; i++)
  {
    Epaper_Write_Data(0x00);
  }

  EPD_Update();
}
void EPD_Update(void)
{
  Epaper_Write_Command(0x22); //Display Update Control
  Epaper_Write_Data(0xc7);
  Epaper_Write_Command(0x20); //Activate Display Update Sequence
  Epaper_READBUSY();
}

void EPD_Part_Update(void)
{
  Epaper_Write_Command(0x22); //Display Update Control
  Epaper_Write_Data(0xff);
  Epaper_Write_Command(0x20); //Activate Display Update Sequence
  Epaper_READBUSY();
}

void EPD_DeepSleep(void)
{
  Epaper_Write_Command(0x10); //enter deep sleep
  Epaper_Write_Data(0x03);
  //DelayMs(100);
}

//��δ֪��ȷ���Ƿ񴥷����Ź�����ʱ�߼��д��Ľ�
void Epaper_READBUSY(void)
{
  //unsigned int i = 0;
  while (1)
  {
    //i = i + 1;
    if (isEPD_W21_BUSY == 0)
        break;
    //if (i == 20)
        //break;
    DelayUs(10);
  }
}

//////////// ��ˢ /////////////
void EPD_SetRAMValue_BaseMap(const unsigned char *datas)
{
  unsigned int i;
  const unsigned char *datas_flag;
  datas_flag = datas;
  Epaper_Write_Command(0x24); //Write Black and White image to RAM
  for (i = 0; i < ALLSCREEN_GRAGHBYTES; i++)
  {
    Epaper_Write_Data(&datas[i]);
  }
  datas = datas_flag;
  Epaper_Write_Command(0x26); //Write Black and White image to RAM
  for (i = 0; i < ALLSCREEN_GRAGHBYTES; i++)
  {  //�˴�ӦΪpgm_read_byte(&datas[i]) ��ʱ������ֲ
    Epaper_Write_Data(&datas[i]);
  }
  EPD_Update();
  EPD_Part_Init();
}

void EPD_Dis_Part(unsigned int x_start, unsigned int y_start, const unsigned char *datas, unsigned int PART_COLUMN, unsigned int PART_LINE)
{
  unsigned int i;
  unsigned int x_end, y_start1, y_start2, y_end1, y_end2;
  x_start = x_start / 8; //
  x_end = x_start + PART_LINE / 8 - 1;

  y_start1 = 0;
  y_start2 = y_start;
  if (y_start >= 256)
  {
    y_start1 = y_start2 / 256;
    y_start2 = y_start2 % 256;
  }
  y_end1 = 0;
  y_end2 = y_start + PART_COLUMN - 1;
  if (y_end2 >= 256)
  {
    y_end1 = y_end2 / 256;
    y_end2 = y_end2 % 256;
  }
  //Reset
  EPD_3C266_RST_0; // Module reset
  DelayMs(1);    //At least 10ms delay
  EPD_3C266_RST_1;
  DelayMs(1); //At least 10ms delay

  Epaper_Write_Command(0x3C); //BorderWavefrom
  Epaper_Write_Data(0x80);
  //
  Epaper_Write_Command(0x44);  // set RAM x address start/end, in page 35
  Epaper_Write_Data(x_start);  // RAM x address start at 00h;
  Epaper_Write_Data(x_end);    // RAM x address end at 0fh(15+1)*8->128
  Epaper_Write_Command(0x45);  // set RAM y address start/end, in page 35
  Epaper_Write_Data(y_start2); // RAM y address start at 0127h;
  Epaper_Write_Data(y_start1); // RAM y address start at 0127h;
  Epaper_Write_Data(y_end2);   // RAM y address end at 00h;
  Epaper_Write_Data(y_end1);   // ????=0

  Epaper_Write_Command(0x4E); // set RAM x address count to 0;
  Epaper_Write_Data(x_start);
  Epaper_Write_Command(0x4F); // set RAM y address count to 0X127;
  Epaper_Write_Data(y_start2);
  Epaper_Write_Data(y_start1);
  EPD_select_LUT((unsigned char *)LUT_DATA_part);

  //PRINT("׼�����;�ˢ����");
  Epaper_Write_Command(0x24); //Write Black and White image to RAM
  for (i = 0; i < PART_COLUMN * PART_LINE / 8; i++)
  {
    Epaper_Write_Data(&datas[i]);
  }
  //PRINT("������ϣ���ʼˢ��");
  EPD_Part_Update();
}


void EPD_WhiteScreen_Black(void)

{
  unsigned int i, k;
  Epaper_Write_Command(0x24);
  for (i = 0; i < ALLSCREEN_GRAGHBYTES; i++)
  {
    Epaper_Write_Data(0x00);
  }
  Epaper_Write_Command(0x26);
  for (i = 0; i < ALLSCREEN_GRAGHBYTES; i++)
  {
    Epaper_Write_Data(0x00);
  }
  EPD_Update();
}

void EPD_WhiteScreen_White(void)
{
  unsigned int i, k;
  Epaper_Write_Command(0x24);
  for (i = 0; i < ALLSCREEN_GRAGHBYTES; i++)
  {
    Epaper_Write_Data(0xFF);
  }
  Epaper_Write_Command(0x26);
  for (i = 0; i < ALLSCREEN_GRAGHBYTES; i++)
  {
    Epaper_Write_Data(0x00);
  }
  EPD_Update();
}
/*
void EPD_Write(unsigned char *value, unsigned char Datalen)
{

  unsigned char i = 0;
  unsigned char *ptemp;
  ptemp = value;

  Epaper_READBUSY();

  EPD_W21_CS_0;
  EPD_W21_DC_0;      // When DC is 0, write command
  SPI_Write(*ptemp); // The first byte is written with the command value
  ptemp++;
  EPD_W21_DC_1; // When DC is 1, write Data
  for (i = 0; i < Datalen - 1; i++)
  { // sub the Data
    SPI_Write(*ptemp);
    ptemp++;
  }
  EPD_W21_CS_1;
}
*/

void EPD_Part_Init(void)
{
  Epaper_Write_Command(0x2C); //VCOM Voltage
  Epaper_Write_Data(0x26);

  Epaper_READBUSY();
  EPD_select_LUT((unsigned char *)LUT_DATA_part);
  Epaper_Write_Command(0x37);
  Epaper_Write_Data(0x00);
  Epaper_Write_Data(0x00);
  Epaper_Write_Data(0x00);
  Epaper_Write_Data(0x00);
  Epaper_Write_Data(0x40);
  Epaper_Write_Data(0x00);
  Epaper_Write_Data(0x00);

  Epaper_Write_Command(0x22); //Display Update Control
  Epaper_Write_Data(0xC0);
  Epaper_Write_Command(0x20); //Activate Display Update Sequence
  Epaper_READBUSY();

  //  Epaper_Write_Command(0x3C); //BorderWavefrom
  //  Epaper_Write_Data(0x01);
}

void EPD_select_LUT(unsigned char *wave_data)
{
  unsigned char count;
  Epaper_Write_Command(0x32);
  for (count = 0; count < 70; count++)
    Epaper_Write_Data(wave_data[count]);
}

int main()
{
  //����ϵͳ����ʱ��
  SetSysClock( CLK_SOURCE_PLL_60MHz );

  /* ���ô��ڵ��� */
  //DebugInit();

  //īˮ��DC RST BUSY���Ŷ�ӦIO��ʼ��
  EPD_IO_INIT();

  //SPI0��ӦIO��ʼ������SPI0��ʼ��
  SPI0_INIT();

  //ȫˢ��ʼ��
  //PRINT("��ʼȫˢ");
  //EPD_HW_Init();

  //�׵�ȫˢ
  //EPD_WhiteScreen_ALL(gImage_1);

  //īˮ�����˯��
  //EPD_DeepSleep();

  //DelayMs(2000);

  //ˢ��
  EPD_HW_Init();           //Electronic paper initialization
  EPD_WhiteScreen_Black(); //Show all white
  EPD_DeepSleep();

  //DelayMs(2000);

  EPD_HW_Init();
  EPD_WhiteScreen_White();
  EPD_DeepSleep();

//  while(1){
//
//  }
}

